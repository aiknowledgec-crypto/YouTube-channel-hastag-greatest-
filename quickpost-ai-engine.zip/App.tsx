
import React, { useState } from 'react';
import { Platform, Language } from './types';
import { generateContent } from './services/geminiService';
import Header from './components/Header';
import CopyButton from './components/CopyButton';

const App: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState<Platform>(Platform.YouTube);
  const [language, setLanguage] = useState<Language>(Language.English);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copyAllStatus, setCopyAllStatus] = useState(false);

  const handleGenerate = async () => {
    if (!topic.trim()) {
      setError('Please enter a content topic.');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const output = await generateContent({ topic, platform, language });
      setResult(output);
    } catch (err: any) {
      setError(err.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  const parseResult = (raw: string) => {
    const parts = raw.split(/\n(?=[A-Z]+:)/);
    return parts.map(part => {
      const [label, ...contentArr] = part.split('\n');
      const content = contentArr.join('\n').trim();
      return { label: label.replace(':', '').trim(), content };
    }).filter(p => p.content.length > 0);
  };

  const handleCopyAll = async () => {
    if (!result) return;
    const parsed = parseResult(result);
    const fullText = parsed.map(item => `${item.label}:\n${item.content}`).join('\n\n');
    
    try {
      await navigator.clipboard.writeText(fullText);
      setCopyAllStatus(true);
      setTimeout(() => setCopyAllStatus(false), 2000);
    } catch (err) {
      console.error('Failed to copy all content', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-white max-w-xl mx-auto selection:bg-indigo-500/30">
      <Header />

      <main className="p-6 pb-32 space-y-10">
        {/* Topic Entry */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-[#444] font-bold text-[10px] tracking-[0.15em] uppercase">
            <i className="fas fa-newspaper text-xs"></i>
            <span>Topic Entry</span>
          </div>
          <textarea
            className="w-full bg-transparent border-b border-[#222] focus:border-indigo-500 p-0 py-4 text-2xl font-bold placeholder:text-[#222] outline-none transition-colors resize-none h-24"
            placeholder="Enter content topic..."
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          />
        </div>

        {/* Platform Selection */}
        <div className="space-y-4">
          <div className="text-[#444] font-bold text-[10px] tracking-[0.15em] uppercase">Platform</div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: Platform.YouTube, icon: 'fa-youtube', label: 'YouTube' },
              { id: Platform.Instagram, icon: 'fa-instagram', label: 'Instagram' },
              { id: Platform.WhatsApp, icon: 'fa-comment', label: 'WhatsApp' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setPlatform(p.id)}
                className={`flex flex-col items-center justify-center gap-3 py-6 rounded-2xl transition-all duration-300 border ${
                  platform === p.id 
                    ? 'bg-[#5D5CDE] border-[#5D5CDE] text-white' 
                    : 'bg-[#121212] border-[#1a1a1a] text-[#555] hover:border-gray-700'
                }`}
              >
                <i className={`fab ${p.icon} text-xl`}></i>
                <span className="text-[10px] font-black tracking-widest uppercase">{p.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Language Selection */}
        <div className="space-y-4">
          <div className="text-[#444] font-bold text-[10px] tracking-[0.15em] uppercase">Language</div>
          <div className="bg-[#121212] p-1.5 rounded-2xl grid grid-cols-2 gap-2 border border-[#1a1a1a]">
            {[Language.English, Language.Hindi].map((l) => (
              <button
                key={l}
                onClick={() => setLanguage(l)}
                className={`py-3.5 rounded-xl font-bold transition-all duration-300 text-sm ${
                  language === l 
                    ? 'bg-[#5D5CDE] text-white shadow-lg' 
                    : 'bg-transparent text-[#555] hover:text-gray-300'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Error Handling */}
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-sm font-medium flex items-center gap-3 animate-pulse">
            <i className="fas fa-exclamation-circle"></i>
            {error}
          </div>
        )}

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={loading}
          className={`w-full py-5 rounded-3xl font-black text-white uppercase tracking-widest text-sm flex items-center justify-center gap-3 transition-all active:scale-[0.98] ${
            loading 
              ? 'bg-gray-800 text-gray-500 cursor-not-allowed' 
              : 'bg-gradient-to-r from-[#5D5CDE] to-[#3B39C7] hover:shadow-[0_10px_30px_rgba(93,92,222,0.4)] shadow-[0_4px_15px_rgba(93,92,222,0.3)]'
          }`}
        >
          {loading ? (
            <i className="fas fa-circle-notch animate-spin text-lg"></i>
          ) : (
            <>
              <i className="fas fa-sparkles text-lg"></i>
              Generate Content
            </>
          )}
        </button>

        {/* Results */}
        {result && (
          <div className="space-y-6 pt-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
             <div className="flex items-center justify-between border-t border-[#1a1a1a] pt-8">
              <div className="flex items-center gap-2 text-[#444] font-bold text-[10px] tracking-[0.15em] uppercase">
                <i className="fas fa-stars text-xs text-indigo-500"></i>
                <span>Result Output</span>
              </div>
              
              <button 
                onClick={handleCopyAll}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${
                  copyAllStatus 
                    ? 'bg-green-500 text-white' 
                    : 'bg-white text-black hover:bg-gray-200'
                }`}
              >
                <i className={`fas ${copyAllStatus ? 'fa-check-double' : 'fa-copy'}`}></i>
                {copyAllStatus ? 'Copied Everything' : 'Copy All'}
              </button>
            </div>

            {parseResult(result).map((item, idx) => (
              <div key={idx} className="bg-[#121212] p-6 rounded-3xl border border-[#1a1a1a] space-y-4 group hover:border-indigo-500/30 transition-colors">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-indigo-400 tracking-widest uppercase bg-indigo-500/10 px-3 py-1.5 rounded-full border border-indigo-500/20">
                    {item.label}
                  </span>
                  <CopyButton text={item.content} />
                </div>
                <div className="text-gray-300 text-base leading-relaxed font-medium">
                  {item.content}
                </div>
              </div>
            ))}

            <div className="pt-8 flex justify-center">
               <button 
                onClick={() => setResult(null)}
                className="text-[#333] hover:text-white transition-colors text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-3"
              >
                <i className="fas fa-rotate-left"></i>
                Reset Engine
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
