
export enum Platform {
  YouTube = 'YouTube',
  Instagram = 'Instagram',
  WhatsApp = 'WhatsApp'
}

export enum Language {
  Hindi = 'Hindi',
  English = 'English'
}

export interface GenerationRequest {
  topic: string;
  platform: Platform;
  language: Language;
}

export interface GenerationResult {
  title?: string;
  description?: string;
  shortCaption?: string;
  mediumCaption?: string;
  shortStatus?: string;
  mediumStatus?: string;
  hashtags?: string;
  raw: string;
}
