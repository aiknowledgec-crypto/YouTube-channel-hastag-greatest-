
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="px-6 py-6 flex items-center justify-between bg-[#0D0D0D] border-b border-gray-800/50 sticky top-0 z-50">
      <div className="flex items-center gap-4">
        <div className="w-11 h-11 bg-gradient-to-br from-[#6366f1] to-[#4f46e5] rounded-xl flex items-center justify-center text-white shadow-[0_0_20px_rgba(99,102,241,0.3)]">
          <i className="fas fa-bolt text-xl"></i>
        </div>
        <h1 className="text-2xl font-black italic tracking-tighter text-white uppercase">
          Engine V2
        </h1>
      </div>
      <button className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white transition-colors">
        <i className="fas fa-palette text-xl"></i>
      </button>
    </header>
  );
};

export default Header;
